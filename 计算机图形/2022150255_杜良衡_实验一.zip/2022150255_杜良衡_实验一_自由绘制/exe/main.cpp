#include "Angel.h"
#include <string>

const glm::vec3 WHITE(1.0, 1.0, 1.0);
const glm::vec3 BLACK(0.0, 0.0, 0.0);
const glm::vec3 RED(1.0, 0.0, 0.0);
const glm::vec3 GREEN(0.0, 1.0, 0.0);
const glm::vec3 BLUE(0.0, 0.0, 1.0);
const int CIRCLE_NUM_POINTS = 100;
const int ELLIPSE_NUM_POINTS = 100;
const int TRIANGLE_NUM_POINTS = 3;
const int SQUARE_NUM = 1;
const int SQUARE_NUM_POINTS = 4 * SQUARE_NUM;
const int LINE_NUM_POINTS = 2;

// 每当窗口改变大小，GLFW会调用这个函数并填充相应的参数
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	glViewport(0, 0, width, height);
}

// 根据角度生成颜色
float generateAngleColor(double angle)
{
	return 1.0 / (2 * M_PI) * angle;
}

// 获得三角形的每个角度
double getTriangleAngle(int point)
{
	return 2 * M_PI / 3 * point;
}

// 获得正方形的每个角度
double getSquareAngle(int point)
{
	return M_PI / 4 + (M_PI / 2 * point);
}

// 计算椭圆/圆上的点
glm::vec2 getEllipseVertex(glm::vec2 center, double scale, double verticalScale, double angle)
{
	glm::vec2 vertex(sin(angle), cos(angle));
	vertex *= scale;
	vertex.y /= verticalScale;
	vertex += center;
	return vertex;
}


// 获得椭圆/圆的每个顶点
void generateEllipsePoints(glm::vec2 vertices[], glm::vec3 colors[], int startVertexIndex, int numPoints,
	glm::vec2 center, double scale, double verticalScale, glm::vec3 color)
{
	double angleIncrement = (2 * M_PI) / numPoints;
	double currentAngle = M_PI / 2;

	for (int i = startVertexIndex; i < startVertexIndex + numPoints; ++i) {
		vertices[i] = getEllipseVertex(center, scale, verticalScale, currentAngle);
		if (verticalScale == 1.0) {
			colors[i] = glm::vec3(generateAngleColor(currentAngle), 0.0, 0.0);
		}
		else {
			colors[i] = color;
		}
		currentAngle += angleIncrement;
	}
}

// 获得三角形的每个顶点
void generateTrianglePoints(glm::vec2 vertices[], glm::vec3 colors[], int startVertexIndex, glm::vec3 color, glm::vec2 center, double angle)
{
	glm::vec2 scale(0.1, 0.1);

	for (int i = 0; i < 3; ++i) {
		double currentAngle = getTriangleAngle(i) + angle;
		vertices[startVertexIndex + i] = glm::vec2(cos(currentAngle), sin(currentAngle)) * scale + center;
	}

	colors[startVertexIndex] = color;
	colors[startVertexIndex + 1] = color;
	colors[startVertexIndex + 2] = color;
}

//vao用来存储顶点数组对象，program存储OpenGL着色器程序的标识符
GLuint vao[50], program;
// 创建顶点缓存对象，vbo[2]是因为我们将要使用两个缓存对象
GLuint vbo[2];

//创建圆锥曲线
void createConic(glm::vec2 center, double a, double b, int i, glm::vec3 color, double scale) {
	//定义圆锥曲线的点
	glm::vec2 conic_vertices[ELLIPSE_NUM_POINTS];
	glm::vec3 conic_colors[ELLIPSE_NUM_POINTS];

	for (int i = 0; i < ELLIPSE_NUM_POINTS; i++) {
		double s = i * 2 * M_PI / ELLIPSE_NUM_POINTS;
		double r = 1.0 / (1 + a * cos(s + b));
		double x = 0.3 * scale * r * cos(s);
		double y = 0.3 * scale * r * sin(s);
		conic_vertices[i] = glm::vec2(x, y) + center;
		conic_colors[i] = color;
	}
	glGenVertexArrays(1, &vao[i]);
	glBindVertexArray(vao[i]);

	glGenBuffers(1, &vbo[0]);
	glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(conic_vertices), conic_vertices, GL_STATIC_DRAW);
	GLuint location = glGetAttribLocation(program, "vPosition");
	glEnableVertexAttribArray(location);
	glVertexAttribPointer(
		location,
		2,
		GL_FLOAT,
		GL_FALSE,
		sizeof(glm::vec2),
		BUFFER_OFFSET(0));

	glGenBuffers(1, &vbo[1]);
	glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(conic_colors), conic_colors, GL_STATIC_DRAW);
	GLuint cLocation = glGetAttribLocation(program, "vColor");
	glEnableVertexAttribArray(cLocation);
	glVertexAttribPointer(
		cLocation,
		3,
		GL_FLOAT,
		GL_FALSE,
		sizeof(glm::vec3),
		BUFFER_OFFSET(0));
}

//椭圆创建
void createEllipse(glm::vec2 ellipsecenter, glm::vec3 color, int i, double scale, double verticalScale) {
	// 定义椭圆的点
	glm::vec2 ellipse_vertices[ELLIPSE_NUM_POINTS];
	glm::vec3 ellipse_colors[ELLIPSE_NUM_POINTS];
	//生成椭圆的顶点和颜色数据
	/*
	参数从左到右依次为：存储顶点坐标数组，存储顶点颜色数组，
	从数组索引为0的位置即第一个元素开始存储顶点数据，顶点数量，
	中心点坐标，水平方向的缩放因子，垂直方向的缩放因子，颜色
	*/
	generateEllipsePoints(ellipse_vertices, ellipse_colors, 0, ELLIPSE_NUM_POINTS, ellipsecenter, scale, verticalScale, color);//椭圆

	glGenVertexArrays(1, &vao[i]);
	glBindVertexArray(vao[i]);

	glGenBuffers(1, &vbo[0]);
	glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(ellipse_vertices), ellipse_vertices, GL_STATIC_DRAW);
	GLuint location = glGetAttribLocation(program, "vPosition");
	glEnableVertexAttribArray(location);
	glVertexAttribPointer(
		location,
		2,
		GL_FLOAT,
		GL_FALSE,
		sizeof(glm::vec2),
		BUFFER_OFFSET(0));

	glGenBuffers(1, &vbo[1]);
	glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(ellipse_colors), ellipse_colors, GL_STATIC_DRAW);
	GLuint cLocation = glGetAttribLocation(program, "vColor");
	glEnableVertexAttribArray(cLocation);
	glVertexAttribPointer(
		cLocation,
		3,
		GL_FLOAT,
		GL_FALSE,
		sizeof(glm::vec3),
		BUFFER_OFFSET(0));

}

//四边形创建
void createQuad(glm::vec2 quad_vertices[], glm::vec3 color, int i) {
	glm::vec2 vertices[SQUARE_NUM_POINTS];
	glm::vec3 colors[SQUARE_NUM_POINTS];

	for (int k = 0; k < SQUARE_NUM_POINTS; k++) {
		vertices[k] = quad_vertices[k];
		colors[k] = color;
	}

	glGenVertexArrays(1, &vao[i]);
	glBindVertexArray(vao[i]);

	glGenBuffers(1, &vbo[0]);
	glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
	GLuint location = glGetAttribLocation(program, "vPosition");
	glEnableVertexAttribArray(location);
	glVertexAttribPointer(
		location,
		2,
		GL_FLOAT,
		GL_FALSE,
		sizeof(glm::vec2),
		BUFFER_OFFSET(0));

	glGenBuffers(1, &vbo[1]);
	glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(colors), colors, GL_STATIC_DRAW);
	GLuint cLocation = glGetAttribLocation(program, "vColor");
	glEnableVertexAttribArray(cLocation);
	glVertexAttribPointer(
		cLocation,
		3,
		GL_FLOAT,
		GL_FALSE,
		sizeof(glm::vec3),
		BUFFER_OFFSET(0));

}

void createTriangle(int i, glm::vec3 color, glm::vec2 center, double angle) {
	// 定义三角形的点
	glm::vec2 triangle_vertices[TRIANGLE_NUM_POINTS];
	glm::vec3 triangle_colors[TRIANGLE_NUM_POINTS];

	// 调用生成形状顶点位置的函数
	generateTrianglePoints(triangle_vertices, triangle_colors, 0, color, center, angle);

	/*
	* 初始化三角形的数据
	*/

	glGenVertexArrays(1, &vao[i]);
	glBindVertexArray(vao[i]);

	glGenBuffers(1, &vbo[0]);
	glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(triangle_vertices), triangle_vertices, GL_STATIC_DRAW);
	GLuint location = glGetAttribLocation(program, "vPosition");
	glEnableVertexAttribArray(location);
	glVertexAttribPointer(
		location,
		2,
		GL_FLOAT,
		GL_FALSE,
		sizeof(glm::vec2),
		BUFFER_OFFSET(0));

	glGenBuffers(1, &vbo[1]);
	glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(triangle_colors), triangle_colors, GL_STATIC_DRAW);
	GLuint cLocation = glGetAttribLocation(program, "vColor");
	glEnableVertexAttribArray(cLocation);
	glVertexAttribPointer(
		cLocation,
		3,
		GL_FLOAT,
		GL_FALSE,
		sizeof(glm::vec3),
		BUFFER_OFFSET(0));
}

void init()
{
	// 读取着色器并使用
	std::string vshader, fshader;
	vshader = "shaders/vshader.glsl";
	fshader = "shaders/fshader.glsl";
	program = InitShader(vshader.c_str(), fshader.c_str());
	glUseProgram(program);
	
	glm::vec3 color1(0.7, 0.8, 0.4); //浅绿
	glm::vec3 color2(0.463, 0.561, 0.282); //浓绿
	
	//前脸
	glm::vec2 ellipsecenter1(0, -0.54);
	createConic(ellipsecenter1, 0.77, 0.55, 1, color2, 0.68);
	createConic(ellipsecenter1, 0.77, 0.55, 4, color1, 0.63);
	//头
	glm::vec2 ellipsecenter2(0, -0.36);
	createEllipse(ellipsecenter2, color2, 2, 0.68, 1.5);
	createEllipse(ellipsecenter2, color1, 5, 0.63, 1.5);
	//身体
	glm::vec2 vertices1[SQUARE_NUM_POINTS] = {
	glm::vec2(-0.50, -1.00),
	glm::vec2(0.50, -1.00),
	glm::vec2(0.30, -0.40),
	glm::vec2(-0.30, -0.40)
	};
	createQuad(vertices1, color1, 6);
	//身体轮廓
	glm::vec2 vertices2[SQUARE_NUM_POINTS] = {
	glm::vec2(-0.55, -1.0),
	glm::vec2(0.55, -1.0),
	glm::vec2(0.35, -0.4),
	glm::vec2(-0.35, -0.4)
	};
	createQuad(vertices2, color2, 3);
	//右眼
	glm::vec2 ellipsecenter3(0.2, 0.10);
	createEllipse(ellipsecenter3, color2, 14, 0.25, 1.0001); 
	createEllipse(ellipsecenter3, WHITE, 16, 0.20, 1.0001);
	createEllipse(ellipsecenter3, BLACK, 17, 0.07, 1.0001);
	//左眼
	glm::vec2 ellipsecenter4(-0.25, 0.10);
	createEllipse(ellipsecenter4, color2, 15, 0.25, 1.0001);
	createEllipse(ellipsecenter4, WHITE, 18, 0.20, 1.0001);
	createEllipse(ellipsecenter4, BLACK, 19, 0.07, 1.0001);
	
	
	
	//背部突起
	glm::vec2 center1(0.59, -0.10);
	double angle1 = 5 / (3 * M_PI);
	createTriangle(27, color2, center1, angle1);

	glm::vec2 center2(0.69, -0.25);
	double angle2 = 1.7 / (3 * M_PI);
	createTriangle(28, color2, center2, angle2);

	glm::vec2 center3(0.69, -0.46);
	double angle3 = -1.5 / (3 * M_PI);
	createTriangle(29, color2, center3, angle3);

	glm::vec2 center4(0.52, -0.79);
	double angle4 = 3 / (3 * M_PI);
	createTriangle(30, color2, center4, angle4);

	glm::vec2 center5(0.56, -0.93);
	double angle5 = 2 / (3 * M_PI);
	createTriangle(31, color2, center5, angle5);
	glClearColor(1.0, 1.0, 1.0, 1.0);
	
	//嘴巴
	glm::vec2 vertices3[SQUARE_NUM_POINTS] = {
	glm::vec2(-0.60, -0.5),
	glm::vec2(0.25, -0.48),
	glm::vec2(0.25, -0.41),
	glm::vec2(-0.652, -0.43)
	};
	createQuad(vertices3, color2, 21);
	//构建嘴部圆弧
	glm::vec2 ellipsecenter5(0.36, -0.44);
	createEllipse(ellipsecenter5, color2, 22, 0.15, 1.0001);

	glm::vec2 ellipsecenter6(0.42, -0.44);
	createEllipse(ellipsecenter6, color1, 23, 0.13, 1.0001);
	glm::vec2 vertices4[SQUARE_NUM_POINTS] = {
	glm::vec2(0.33, -0.62),
	glm::vec2(0.33, -0.26),
	glm::vec2(0.47, -0.26),
	glm::vec2(0.47, -0.62)
	};
	createQuad(vertices4, color1, 24);

	glm::vec2 ellipsecenter7(0.33, -0.56);
	createEllipse(ellipsecenter7, color2, 25, 0.0265, 1.0001);
	glm::vec2 ellipsecenter8(0.33, -0.32);
	createEllipse(ellipsecenter8, color2, 26, 0.0265, 1.0001);

	//设置背景为白色
	glClearColor(1, 1, 1, 1);
}

void display(void)
{

	glClear(GL_COLOR_BUFFER_BIT);

	glUseProgram(program);

	for (int i = 1; i < 27; i++) {
		if (i == 3 || i == 6 || i == 21||i == 24)	//若为四边形
		{
		glBindVertexArray(vao[i]);	//将vao顶点数组对象绑定当前OpenGL上下文
		//调用了绘制图形函数
		//指定了绘制模式GL_TRIANGLE_FAN，从顶点数组索引为0即第一个顶点开始绘制，以及绘制顶点数量
		glDrawArrays(GL_TRIANGLE_FAN, 0, SQUARE_NUM_POINTS);
		}
		else {
		//否则按椭圆绘制
		glBindVertexArray(vao[i]);
		
		glDrawArrays(GL_TRIANGLE_FAN, 0, ELLIPSE_NUM_POINTS);
		}
		
	}
	for (int i = 27; i < 32; i++) {
		glBindVertexArray(vao[i]);
		glDrawArrays(GL_TRIANGLE_FAN, 0, TRIANGLE_NUM_POINTS);
	}
	
	
	glFlush();
}

int main(int argc, char** argv)
{
	// 初始化GLFW库
	glfwInit();

	// 配置GLFW
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	// 配置窗口属性
	GLFWwindow* window = glfwCreateWindow(512, 512, "2022150255_杜良衡_实验一", NULL, NULL);
	//创建窗口失败输出提示
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();	//初始化终止，释放资源
		return -1;
	}
	//绑定OpenGL上下文到窗口上
	glfwMakeContextCurrent(window);
	//设置窗口大小变化回调函数
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

	// 调用任何OpenGL的函数之前初始化GLAD
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}

	init();

	std::cout << "OpenGL Vendor: " << glGetString(GL_VENDOR) << std::endl;
	std::cout << "OpenGL Renderer: " << glGetString(GL_RENDERER) << std::endl;
	std::cout << "OpenGL Version: " << glGetString(GL_VERSION) << std::endl;
	std::cout << "Supported GLSL version is: " << glGetString(GL_SHADING_LANGUAGE_VERSION) << std::endl;


	while (!glfwWindowShouldClose(window))
	{
		display();
		// 交换颜色缓冲 以及 检查有没有触发什么事件（比如键盘输入、鼠标移动等）
		glfwSwapBuffers(window);
		glfwPollEvents();
	}
	return 0;
}
